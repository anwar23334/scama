<?php

header("Location: https://www.rbcroyalbank.com/personal.html/");

?>